const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db = require('../db');

// POST /api/auth/register
router.post('/register', [
  body('name').notEmpty().trim(),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('slug').matches(/^[a-z0-9-]+$/).withMessage('Slug must be lowercase letters, numbers, hyphens'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { name, email, password, slug, description, cuisine_type, address, city, phone, google_place_id } = req.body;

  try {
    const existing = await db.query('SELECT id FROM restaurants WHERE email=$1 OR slug=$2', [email, slug]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'Email or slug already registered' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const { rows: [restaurant] } = await db.query(`
      INSERT INTO restaurants (name, slug, description, cuisine_type, address, city, phone, email, password_hash, google_place_id)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      RETURNING id, name, slug, email, created_at
    `, [name, slug, description, cuisine_type, address, city, phone, email, password_hash, google_place_id]);

    const token = jwt.sign(
      { id: restaurant.id, email: restaurant.email, slug: restaurant.slug },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.status(201).json({ restaurant, token });
  } catch (err) {
    res.status(500).json({ error: 'Registration failed', detail: err.message });
  }
});

// POST /api/auth/login
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { email, password } = req.body;

  try {
    const { rows: [restaurant] } = await db.query(
      'SELECT id, name, slug, email, password_hash FROM restaurants WHERE email=$1 AND is_active=true',
      [email]
    );
    if (!restaurant) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, restaurant.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: restaurant.id, email: restaurant.email, slug: restaurant.slug },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    const { password_hash, ...safeRestaurant } = restaurant;
    res.json({ restaurant: safeRestaurant, token });
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

module.exports = router;
